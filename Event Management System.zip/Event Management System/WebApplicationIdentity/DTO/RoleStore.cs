﻿namespace WebApplicationIdentity.DTO
{
    public class RoleStore
    {
        public string id {  get; set; }
        public string RoleName { get; set; }
    }
}
